package com.rein.hkpools;

import android.app.Activity;
import android.os.Bundle;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputFilter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int navy = Color.rgb(13, 39, 78);
    private final int blue = Color.rgb(28, 67, 119);
    private final int gold = Color.rgb(240, 180, 55);
    private EditText numberInput, dateInput;
    private TextView resultInfo, statsText, historyText;
    private DB db;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB();
        buildScreen();
        refresh();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(8, 8, 8, 8); return t;
    }
    private Button button(String s, int color) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE);
        b.setTextSize(14); b.setAllCaps(false); b.setBackground(bg(color, 12));
        return b;
    }
    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(16, 18, 16, 24); page.setBackgroundColor(Color.rgb(235,238,243));
        scroll.addView(page); setContentView(scroll);

        LinearLayout header = new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER); header.setPadding(12,18,12,18); header.setBackground(bg(navy,18));
        TextView title = label("HONGKONG POOLS", 23, Color.WHITE, true);
        TextView subtitle = label("NUMBER DATA & STATISTICS", 12, gold, true);
        header.addView(title); header.addView(subtitle); page.addView(header);

        page.addView(sectionTitle("INPUT HASIL 4 DIGIT"));
        dateInput = new EditText(this);
        dateInput.setSingleLine(true); dateInput.setText(new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()));
        dateInput.setHint("Tanggal (YYYY-MM-DD)"); dateInput.setTextSize(16);
        dateInput.setPadding(14,8,14,8); dateInput.setBackground(bg(Color.WHITE,10));
        page.addView(dateInput, matchWrap());
        numberInput = new EditText(this);
        numberInput.setSingleLine(true); numberInput.setTextSize(28); numberInput.setGravity(Gravity.CENTER);
        numberInput.setHint("0000"); numberInput.setInputType(2);
        numberInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});
        numberInput.setLetterSpacing(0.25f); numberInput.setPadding(12,10,12,10);
        numberInput.setBackground(bg(Color.WHITE,10));
        LinearLayout.LayoutParams np = matchWrap(); np.topMargin=10; page.addView(numberInput,np);

        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        Button reset = button("RESET", Color.rgb(174,43,51));
        Button save = button("OK / SIMPAN", Color.rgb(28,125,81));
        actions.addView(reset,new LinearLayout.LayoutParams(0, -2,1));
        Space gap = new Space(this); actions.addView(gap,new LinearLayout.LayoutParams(10,1));
        actions.addView(save,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams ap=matchWrap(); ap.topMargin=10; page.addView(actions,ap);
        reset.setOnClickListener(v -> numberInput.setText(""));
        save.setOnClickListener(v -> saveResult());

        page.addView(sectionTitle("HASIL TERAKHIR"));
        resultInfo = label("Belum ada data tersimpan.",16,navy,true);
        resultInfo.setBackground(bg(Color.WHITE,12)); page.addView(resultInfo,matchWrap());

        page.addView(sectionTitle("STATISTIK FREKUENSI DIGIT"));
        statsText = label("",14,Color.DKGRAY,false);
        statsText.setBackground(bg(Color.WHITE,12)); page.addView(statsText,matchWrap());

        page.addView(sectionTitle("RIWAYAT KELUARAN"));
        historyText = label("",14,Color.DKGRAY,false);
        historyText.setBackground(bg(Color.WHITE,12)); page.addView(historyText,matchWrap());

        Button clear = button("HAPUS SEMUA RIWAYAT", Color.rgb(95,103,115));
        LinearLayout.LayoutParams cp=matchWrap(); cp.topMargin=14; page.addView(clear,cp);
        clear.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
            .setTitle("Hapus semua riwayat?")
            .setMessage("Data yang dihapus tidak dapat dikembalikan.")
            .setNegativeButton("BATAL",null)
            .setPositiveButton("HAPUS",(d,w)->{ db.getWritableDatabase().delete("results",null,null); refresh(); })
            .show());
        page.addView(label("Catatan: statistik hanya merangkum data yang Anda masukkan. Tidak dapat memprediksi atau menjamin hasil undian berikutnya.",11,Color.GRAY,false));
    }
    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=8; return p;
    }
    private TextView sectionTitle(String s) {
        TextView t=label(s,15,navy,true); t.setPadding(2,18,2,8); return t;
    }
    private void saveResult() {
        String n=numberInput.getText().toString().trim();
        String date=dateInput.getText().toString().trim();
        if (!n.matches("\\d{4}")) { numberInput.setError("Masukkan tepat 4 digit, termasuk nol di depan."); return; }
        if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) { dateInput.setError("Gunakan format YYYY-MM-DD."); return; }
        ContentValues cv=new ContentValues(); cv.put("date",date); cv.put("number",n);
        db.getWritableDatabase().insert("results",null,cv);
        numberInput.setText(""); Toast.makeText(this,"Hasil berhasil disimpan",Toast.LENGTH_SHORT).show(); refresh();
    }
    private void refresh() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT date,number FROM results ORDER BY id DESC LIMIT 1",null);
        if(c.moveToFirst()) {
            String date=c.getString(0), n=c.getString(1);
            resultInfo.setText("Tanggal: "+date+"\nHasil 4 digit:  "+n+
                "\nDigit 1: "+n.charAt(0)+"   Digit 2: "+n.charAt(1)+
                "\nDigit 3: "+n.charAt(2)+"   Digit 4: "+n.charAt(3));
        } else resultInfo.setText("Belum ada data tersimpan.");
        c.close();

        int[] counts=new int[10]; int total=0;
        Cursor all=db.getReadableDatabase().rawQuery("SELECT number FROM results",null);
        StringBuilder hist=new StringBuilder(); int rows=0;
        while(all.moveToNext()) {
            String n=all.getString(0); for(char ch:n.toCharArray()){counts[ch-'0']++; total++;}
            if(rows<30) {
                Cursor detail=db.getReadableDatabase().rawQuery("SELECT date FROM results WHERE number=? ORDER BY id DESC LIMIT 1",new String[]{n});
                String d=detail.moveToFirst()?detail.getString(0):"";
                detail.close(); hist.append(d).append("   ").append(n).append("\n");
            }
            rows++;
        }
        all.close();
        StringBuilder st=new StringBuilder("Jumlah data: ").append(rows).append("\nTotal digit dianalisis: ").append(total).append("\n\n");
        for(int i=0;i<10;i++) st.append(i).append(" : ").append(counts[i]).append(" kali\n");
        statsText.setText(st.toString());
        historyText.setText(rows==0?"Belum ada riwayat.":hist.toString());
    }
    private class DB extends SQLiteOpenHelper {
        DB(){super(MainActivity.this,"hk_pools.db",null,1);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE results(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,number TEXT NOT NULL)");}
        public void onUpgrade(SQLiteDatabase d,int oldV,int newV){}
    }
}
