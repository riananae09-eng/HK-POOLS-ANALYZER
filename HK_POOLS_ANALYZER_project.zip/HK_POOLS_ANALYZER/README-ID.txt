HK POOLS ANALYZER - PROYEK ANDROID

Isi:
- Input hasil 4 digit dan tanggal
- Simpan riwayat secara lokal di perangkat
- Statistik frekuensi digit 0-9 dari data yang dimasukkan
- Hapus riwayat
- Tampilan biru gelap

CARA MENGHASILKAN APK DENGAN HP ANDROID:
1. Ekstrak ZIP ini.
2. Buat akun / masuk ke GitHub melalui browser.
3. Buat repository baru bernama HK-POOLS-ANALYZER.
4. Upload semua isi folder proyek (bukan folder ZIP-nya) ke repository.
5. Pastikan folder .github/workflows ikut terunggah.
6. Buka tab Actions pada repository.
7. Pilih "Build Android APK", lalu tekan "Run workflow" jika belum berjalan otomatis.
8. Tunggu sampai proses selesai dengan tanda hijau.
9. Buka hasil workflow dan unduh artifact bernama HK-POOLS-ANALYZER-APK.
10. Ekstrak artifact ZIP, lalu buka app-debug.apk di HP dan izinkan instalasi dari sumber tersebut jika Android memintanya.

CATATAN:
- APK belum disertakan karena lingkungan ini tidak memiliki Android SDK/Gradle untuk membangun APK secara langsung.
- GitHub Actions akan membangun APK debug dari source code ini.
- Data disimpan lokal di HP dan tidak dikirim ke server.
- Statistik hanya menghitung data historis yang dimasukkan, bukan prediksi hasil undian.
